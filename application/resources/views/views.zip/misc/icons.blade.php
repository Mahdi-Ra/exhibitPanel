<div class="icon-list-demo row icons-selector-overlay">
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-user"> <i class="sl-icon-user"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-people"> <i class="sl-icon-people"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-user-female"> <i class="sl-icon-user-female"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-user-follow"> <i class="sl-icon-user-follow"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-user-following"> <i class="sl-icon-user-following"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-user-unfollow"> <i class="sl-icon-user-unfollow"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-login"> <i class="sl-icon-login"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-logout"> <i class="sl-icon-logout"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-emotsmile"> <i class="sl-icon-emotsmile"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-phone"> <i class="sl-icon-phone"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-call-end"> <i class="sl-icon-call-end"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-call-in"> <i class="sl-icon-call-in"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-call-out"> <i class="sl-icon-call-out"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-map"> <i class="sl-icon-map"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-location-pin"> <i class="sl-icon-location-pin"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-direction"> <i class="sl-icon-direction"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-directions"> <i class="sl-icon-directions"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-compass"> <i class="sl-icon-compass"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-layers"> <i class="sl-icon-layers"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-menu"> <i class="sl-icon-menu"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-list"> <i class="sl-icon-list"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-options-vertical"> <i class="sl-icon-options-vertical"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-options"> <i class="sl-icon-options"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-arrow-down"> <i class="sl-icon-arrow-down"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-arrow-left"> <i class="sl-icon-arrow-left"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-arrow-right"> <i class="sl-icon-arrow-right"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-arrow-up"> <i class="sl-icon-arrow-up"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-arrow-up-circle"> <i class="sl-icon-arrow-up-circle"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-arrow-left-circle"> <i class="sl-icon-arrow-left-circle"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-arrow-right-circle"> <i class="sl-icon-arrow-right-circle"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-arrow-down-circle"> <i class="sl-icon-arrow-down-circle"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-check"> <i class="sl-icon-check"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-clock"> <i class="sl-icon-clock"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-plus"> <i class="sl-icon-plus"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-close"> <i class="sl-icon-close"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-trophy"> <i class="sl-icon-trophy"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-screen-smartphone"> <i class="sl-icon-screen-smartphone"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-screen-desktop"> <i class="sl-icon-screen-desktop"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-plane"> <i class="sl-icon-plane"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-notebook"> <i class="sl-icon-notebook"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-mustache"> <i class="sl-icon-mustache"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-mouse"> <i class="sl-icon-mouse"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-magnet"> <i class="sl-icon-magnet"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-energy"> <i class="sl-icon-energy"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-disc"> <i class="sl-icon-disc"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-cursor"> <i class="sl-icon-cursor"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-cursor-move"> <i class="sl-icon-cursor-move"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-crop"> <i class="sl-icon-crop"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-chemistry"> <i class="sl-icon-chemistry"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-speedometer"> <i class="sl-icon-speedometer"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-shield"> <i class="sl-icon-shield"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-screen-tablet"> <i class="sl-icon-screen-tablet"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-magic-wand"> <i class="sl-icon-magic-wand"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-hourglass"> <i class="sl-icon-hourglass"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-graduation"> <i class="sl-icon-graduation"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-ghost"> <i class="sl-icon-ghost"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-game-controller"> <i class="sl-icon-game-controller"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-fire"> <i class="sl-icon-fire"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-eyeglass"> <i class="sl-icon-eyeglass"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-envelope-open"> <i class="sl-icon-envelope-open"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-envolope-letter"> <i class="sl-icon-envolope-letter"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-bell"> <i class="sl-icon-bell"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-badge"> <i class="sl-icon-badge"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-anchor"> <i class="sl-icon-anchor"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-wallet"> <i class="sl-icon-wallet"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-vector"> <i class="sl-icon-vector"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-speech"> <i class="sl-icon-speech"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-puzzle"> <i class="sl-icon-puzzle"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-printer"> <i class="sl-icon-printer"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-present"> <i class="sl-icon-present"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-playlist"> <i class="sl-icon-playlist"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-pin"> <i class="sl-icon-pin"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-picture"> <i class="sl-icon-picture"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-handbag"> <i class="sl-icon-handbag"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-globe-alt"> <i class="sl-icon-globe-alt"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-globe"> <i class="sl-icon-globe"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-folder-alt"> <i class="sl-icon-folder-alt"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-folder"> <i class="sl-icon-folder"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-film"> <i class="sl-icon-film"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-feed"> <i class="sl-icon-feed"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-drop"> <i class="sl-icon-drop"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-drawar"> <i class="sl-icon-drawar"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-docs"> <i class="sl-icon-docs"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-doc"> <i class="sl-icon-doc"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-diamond"> <i class="sl-icon-diamond"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-cup"> <i class="sl-icon-cup"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-calculator"> <i class="sl-icon-calculator"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-bubbles"> <i class="sl-icon-bubbles"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-briefcase"> <i class="sl-icon-briefcase"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-book-open"> <i class="sl-icon-book-open"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-basket-loaded"> <i class="sl-icon-basket-loaded"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-basket"> <i class="sl-icon-basket"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-bag"> <i class="sl-icon-bag"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-action-undo"> <i class="sl-icon-action-undo"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-action-redo"> <i class="sl-icon-action-redo"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-wrench"> <i class="sl-icon-wrench"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-umbrella"> <i class="sl-icon-umbrella"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-trash"> <i class="sl-icon-trash"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-tag"> <i class="sl-icon-tag"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val=" .icon-support"> <i class="sl-icon-support"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-frame"> <i class="sl-icon-frame"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-size-fullscreen"> <i class="sl-icon-size-fullscreen"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-size-actual"> <i class="sl-icon-size-actual"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-shuffle"> <i class="sl-icon-shuffle"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-share-alt"> <i class="sl-icon-share-alt"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-share"> <i class="sl-icon-share"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-rocket"> <i class="sl-icon-rocket"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-question"> <i class="sl-icon-question"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-pie-chart"> <i class="sl-icon-pie-chart"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-pencil"> <i class="sl-icon-pencil"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-note"> <i class="sl-icon-note"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-loop"> <i class="sl-icon-loop"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-home"> <i class="sl-icon-home"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-grid"> <i class="sl-icon-grid"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-graph"> <i class="sl-icon-graph"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-microphone"> <i class="sl-icon-microphone"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-music-tone-alt"> <i class="sl-icon-music-tone-alt"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-music-tone"> <i class="sl-icon-music-tone"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-earphones-alt"> <i class="sl-icon-earphones-alt"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-earphones"> <i class="sl-icon-earphones"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-equalizer"> <i class="sl-icon-equalizer"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-like"> <i class="sl-icon-like"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-dislike"> <i class="sl-icon-dislike"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-control-start"> <i class="sl-icon-control-start"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-control-rewind"> <i class="sl-icon-control-rewind"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-control-play"> <i class="sl-icon-control-play"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-control-pause"> <i class="sl-icon-control-pause"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-control-forward"> <i class="sl-icon-control-forward"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-control-end"> <i class="sl-icon-control-end"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-volume-1"> <i class="sl-icon-volume-1"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-volume-2"> <i class="sl-icon-volume-2"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-volume-off"> <i class="sl-icon-volume-off"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-calender"> <i class="sl-icon-calender"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-bulb"> <i class="sl-icon-bulb"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-chart"> <i class="sl-icon-chart"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-ban"> <i class="sl-icon-ban"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-bubble"> <i class="sl-icon-bubble"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-camrecorder"> <i class="sl-icon-camrecorder"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-camera"> <i class="sl-icon-camera"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-cloud-download"> <i class="sl-icon-cloud-download"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-cloud-upload"> <i class="sl-icon-cloud-upload"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-eye"> <i class="sl-icon-eye"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-flag"> <i class="sl-icon-flag"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-heart"> <i class="sl-icon-heart"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-info"> <i class="sl-icon-info"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-key"> <i class="sl-icon-key"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-link"> <i class="sl-icon-link"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-lock"> <i class="sl-icon-lock"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-lock-open"> <i class="sl-icon-lock-open"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-magnifier"> <i class="sl-icon-magnifier"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-magnifier-add"> <i class="sl-icon-magnifier-add"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-magnifier-remove"> <i class="sl-icon-magnifier-remove"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-paper-clip"> <i class="sl-icon-paper-clip"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-paper-plane"> <i class="sl-icon-paper-plane"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-power"> <i class="sl-icon-power"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-refresh"> <i class="sl-icon-refresh"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-reload"> <i class="sl-icon-reload"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-settings"> <i class="sl-icon-settings"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-star"> <i class="sl-icon-star"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-symble-female"> <i class="sl-icon-symble-female"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-symbol-male"> <i class="sl-icon-symbol-male"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-target"> <i class="sl-icon-target"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-credit-card"> <i class="sl-icon-credit-card"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-paypal"> <i class="sl-icon-paypal"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-tumblr"> <i class="sl-icon-social-tumblr"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-twitter"> <i class="sl-icon-social-twitter"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-facebook"> <i class="sl-icon-social-facebook"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-instagram"> <i class="sl-icon-social-instagram"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-linkedin"> <i class="sl-icon-social-linkedin"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-pintarest"> <i class="sl-icon-social-pintarest"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-github"> <i class="sl-icon-social-github"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-gplus"> <i class="sl-icon-social-gplus"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-reddit"> <i class="sl-icon-social-reddit"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-skype"> <i class="sl-icon-social-skype"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-dribbble"> <i class="sl-icon-social-dribbble"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-behance"> <i class="sl-icon-social-behance"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-foursqare"> <i class="sl-icon-social-foursqare"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-soundcloud"> <i class="sl-icon-social-soundcloud"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-spotify"> <i class="sl-icon-social-spotify"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-stumbleupon"> <i class="sl-icon-social-stumbleupon"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-youtube"> <i class="sl-icon-social-youtube"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
        <div class="preview js-icon-selector" data-val="sl-icon-social-dropbox"> <i class="sl-icon-social-dropbox"></i></div>
    </div>
    <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-wand"><i class="ti-wand"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-save"><i class="ti-save"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-save-alt"><i class="ti-save-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-direction"><i class="ti-direction"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-direction-alt"><i class="ti-direction-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-user"><i class="ti-user"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-link"><i class="ti-link"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-unlink"><i class="ti-unlink"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-trash"><i class="ti-trash"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-target"><i class="ti-target"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-tag"><i class="ti-tag"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-desktop"><i class="ti-desktop"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-tablet"><i class="ti-tablet"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-mobile"><i class="ti-mobile"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-email"><i class="ti-email"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-star"><i class="ti-star"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-spray"><i class="ti-spray"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-signal"><i class="ti-signal"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-shopping-cart"><i class="ti-shopping-cart"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector"><i class="ti-shopping-cart-full"></i>
            </div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-settings"><i class="ti-settings"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-search"><i class="ti-search"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-zoom-in"><i class="ti-zoom-in"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-zoom-out"><i class="ti-zoom-out"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-cut"><i class="ti-cut"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-ruler"><i class="ti-ruler"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-ruler-alt-2"><i class="ti-ruler-alt-2"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-ruler-pencil"><i class="ti-ruler-pencil"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-ruler-alt"><i class="ti-ruler-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-bookmark"><i class="ti-bookmark"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-bookmark-alt"><i class="ti-bookmark-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-reload"><i class="ti-reload"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-plus"><i class="ti-plus"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-minus"><i class="ti-minus"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-close"><i class="ti-close"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-pin"><i class="ti-pin"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-pencil"><i class="ti-pencil"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-pencil-alt"><i class="ti-pencil-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-paint-roller"><i class="ti-paint-roller"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-paint-bucket"><i class="ti-paint-bucket"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-na"><i class="ti-na"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-medall"><i class="ti-medall"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-medall-alt"><i class="ti-medall-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-marker"><i class="ti-marker"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-marker-alt"><i class="ti-marker-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-lock"><i class="ti-lock"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-unlock"><i class="ti-unlock"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-location-arrow"><i class="ti-location-arrow"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-layout"><i class="ti-layout"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-layers"><i class="ti-layers"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-layers-alt"><i class="ti-layers-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-key"><i class="ti-key"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-image"><i class="ti-image"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-heart"><i class="ti-heart"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-heart-broken"><i class="ti-heart-broken"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-hand-stop"><i class="ti-hand-stop"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-hand-open"><i class="ti-hand-open"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-hand-drag"><i class="ti-hand-drag"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-flag"><i class="ti-flag"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-flag-alt"><i class="ti-flag-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-flag-alt-2"><i class="ti-flag-alt-2"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-eye"><i class="ti-eye"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-import"><i class="ti-import"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-export"><i class="ti-export"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-cup"><i class="ti-cup"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-crown"><i class="ti-crown"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-comments"><i class="ti-comments"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-comment"><i class="ti-comment"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-comment-alt"><i class="ti-comment-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-thought"><i class="ti-thought"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-clip"><i class="ti-clip"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-check"><i class="ti-check"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-check-box"><i class="ti-check-box"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-camera"><i class="ti-camera"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-announcement"><i class="ti-announcement"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-brush"><i class="ti-brush"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-brush-alt"><i class="ti-brush-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-palette"><i class="ti-palette"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-briefcase"><i class="ti-briefcase"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-bolt"><i class="ti-bolt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-bolt-alt"><i class="ti-bolt-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-blackboard"><i class="ti-blackboard"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-bag"><i class="ti-bag"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-world"><i class="ti-world"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-wheelchair"><i class="ti-wheelchair"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-car"><i class="ti-car"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-truck"><i class="ti-truck"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-timer"><i class="ti-timer"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-ticket"><i class="ti-ticket"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-thumb-up"><i class="ti-thumb-up"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-thumb-down"><i class="ti-thumb-down"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-stats-up"><i class="ti-stats-up"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-stats-down"><i class="ti-stats-down"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-shine"><i class="ti-shine"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-shift-right"><i class="ti-shift-right"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-shift-left"><i class="ti-shift-left"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-shift-right-alt"><i class="ti-shift-right-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-shift-left-alt"><i class="ti-shift-left-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-shield"><i class="ti-shield"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-notepad"><i class="ti-notepad"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-server"><i class="ti-server"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-pulse"><i class="ti-pulse"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-printer"><i class="ti-printer"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-power-off"><i class="ti-power-off"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-plug"><i class="ti-plug"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-pie-chart"><i class="ti-pie-chart"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-panel"><i class="ti-panel"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-package"><i class="ti-package"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-music"><i class="ti-music"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-music-alt"><i class="ti-music-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-mouse"><i class="ti-mouse"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-mouse-alt"><i class="ti-mouse-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-money"><i class="ti-money"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-microphone"><i class="ti-microphone"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-menu"><i class="ti-menu"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-menu-alt"><i class="ti-menu-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-map"><i class="ti-map"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-map-alt"><i class="ti-map-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-location-pin"><i class="ti-location-pin"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-light-bulb"><i class="ti-light-bulb"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-info"><i class="ti-info"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-infinite"><i class="ti-infinite"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-id-badge"><i class="ti-id-badge"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-hummer"><i class="ti-hummer"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-home"><i class="ti-home"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-help"><i class="ti-help"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-headphone"><i class="ti-headphone"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-harddrives"><i class="ti-harddrives"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-harddrive"><i class="ti-harddrive"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-gift"><i class="ti-gift"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-game"><i class="ti-game"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-filter"><i class="ti-filter"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-files"><i class="ti-files"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-file"><i class="ti-file"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-zip"><i class="ti-zip"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-folder"><i class="ti-folder"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-envelope"><i class="ti-envelope"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-dashboard"><i class="ti-dashboard"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-cloud"><i class="ti-cloud"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-cloud-up"><i class="ti-cloud-up"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-cloud-down"><i class="ti-cloud-down"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-clipboard"><i class="ti-clipboard"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-calendar"><i class="ti-calendar"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-book"><i class="ti-book"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-bell"><i class="ti-bell"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-basketball"><i class="ti-basketball"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-bar-chart"><i class="ti-bar-chart"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-bar-chart-alt"><i class="ti-bar-chart-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-archive"><i class="ti-archive"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-anchor"><i class="ti-anchor"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-alert"><i class="ti-alert"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-alarm-clock"><i class="ti-alarm-clock"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-agenda"><i class="ti-agenda"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-write"><i class="ti-write"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-wallet"><i class="ti-wallet"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-video-clapper"><i class="ti-video-clapper"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-video-camera"><i class="ti-video-camera"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-vector"><i class="ti-vector"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-support"><i class="ti-support"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-stamp"><i class="ti-stamp"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-slice"><i class="ti-slice"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-shortcode"><i class="ti-shortcode"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-receipt"><i class="ti-receipt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-pin2"><i class="ti-pin2"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-pin-alt"><i class="ti-pin-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-pencil-alt2"><i class="ti-pencil-alt2"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-eraser"><i class="ti-eraser"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-more"><i class="ti-more"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-more-alt"><i class="ti-more-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-microphone-alt"><i class="ti-microphone-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-magnet"><i class="ti-magnet"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-line-double"><i class="ti-line-double"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-line-dotted"><i class="ti-line-dotted"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-line-dashed"><i class="ti-line-dashed"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-ink-pen"><i class="ti-ink-pen"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-info-alt"><i class="ti-info-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-help-alt"><i class="ti-help-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-headphone-alt"><i class="ti-headphone-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-gallery"><i class="ti-gallery"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-face-smile"><i class="ti-face-smile"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-face-sad"><i class="ti-face-sad"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-credit-card"><i class="ti-credit-card"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-comments-smiley"><i class="ti-comments-smiley"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-time"><i class="ti-time"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-share"><i class="ti-share"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-share-alt"><i class="ti-share-alt"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-rocket"><i class="ti-rocket"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-new-window"><i class="ti-new-window"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-rss"><i class="ti-rss"></i></div>
        </div>
        <div class="col-sm-4 col-md-2">
            <div class="preview js-icon-selector" data-val="ti-rss-alt"><i class="ti-rss-alt"></i></div>
        </div>
</div>