<!-- include this for general (in page) notification -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="page-notification">
                    <h2 class="font-weight-200">{{ $page['notification'] ?? '' }}</h2>
                </div>
            </div>
        </div>
    </div>
</div>