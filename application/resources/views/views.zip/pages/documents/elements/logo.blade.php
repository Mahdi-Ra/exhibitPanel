<div class="doc-logo" id="doc-logo">
    <img src="{{ runtimeLogoLarge() }}" alt="homepage" class="logo-large" />            
</div>