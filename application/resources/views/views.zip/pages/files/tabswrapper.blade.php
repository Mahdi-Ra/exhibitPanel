<!-- action buttons -->
@include('pages.files.components.misc.list-page-actions')
<!-- action buttons -->

<!--files table-->
<div class="card-embed-fix">
@include('pages.files.components.table.wrapper')
</div>
<!--files table-->