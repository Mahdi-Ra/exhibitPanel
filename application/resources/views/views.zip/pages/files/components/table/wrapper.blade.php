<!--main table view-->
@include('pages.files.components.table.table')
