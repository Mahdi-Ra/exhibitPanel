<div class="form-group row">
    <label class="col-12 text-left control-label col-form-label">@lang('lang.file_name')</label>
    <div class="col-12">
        <input type="text" class="form-control form-control-sm" id="file_filename" name="file_filename"
            value="{{ $payload['filename'] }}">
    </div>
</div>