<!--main table view-->
@include('pages.categories.components.table.table')