    <div class="hidden payment-gateways" id="gateway-bank">
        <!--bank details-->
        <div class="gateway-bank-details p-t-10 p-b-10">
            {!! clean(config('system.settings_bank_details')) !!}
        </div>
    </div>