<!--main table view-->
@include('pages.knowledgebase.components.table.table')
