<!--TOP STATS-->
<div id="js-trigger-home-client-wrapper">
@include('pages.home.client.widgets.first-row.wrapper')
@include('pages.home.client.widgets.second-row.wrapper')
</div>