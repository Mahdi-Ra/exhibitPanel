<div class="row">

    <!--EVENTS-->
    @include('pages.home.client.widgets.second-row.events')

    <!--PROJECTS-->
    @include('pages.home.client.widgets.second-row.projects')

</div>