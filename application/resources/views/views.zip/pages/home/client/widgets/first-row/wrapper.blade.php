<div class="row">
    <!--PROJECTS PENDING-->
    @include('pages.home.client.widgets.first-row.projects-pending')

    <!--PROJECTS COMPLETED-->
    @include('pages.home.client.widgets.first-row.projects-completed')

    <!--INVOICES DUE-->
    @include('pages.home.client.widgets.first-row.invoices-due')

    <!--INVOICES OVERDUE-->
    @include('pages.home.client.widgets.first-row.invoices-overdue')
</div>