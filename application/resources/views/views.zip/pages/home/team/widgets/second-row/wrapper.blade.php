<div class="row">

    <!--EVENTS-->
    @include('pages.home.team.widgets.second-row.events')

    <!--PROJECTS-->
    @include('pages.home.team.widgets.second-row.projects')

</div>