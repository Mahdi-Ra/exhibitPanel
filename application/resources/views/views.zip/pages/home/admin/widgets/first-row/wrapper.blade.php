<div class="row">
    <!--PAYMENTS TODAY-->
    @include('pages.home.admin.widgets.first-row.payments-today')

    <!--PAYMENTS THIS MONTH-->
    @include('pages.home.admin.widgets.first-row.payments-this-month')

    <!--INVOICES DUE-->
    @include('pages.home.admin.widgets.first-row.invoices-due')

    <!--INVOICES OVERDUE-->
    @include('pages.home.admin.widgets.first-row.invoices-overdue')
</div>