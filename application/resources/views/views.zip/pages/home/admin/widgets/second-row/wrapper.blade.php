<div class="row">

    <!--INCOME-->
    @include('pages.home.admin.widgets.second-row.income')


    <!--LEADS-->
    @include('pages.home.admin.widgets.second-row.leads')


</div>