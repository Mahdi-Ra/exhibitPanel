<div class="col-lg-4  col-md-12">
    <div class="card">
        <div class="card-body text-right">
            <h5 class="card-title">{{ cleanLang(__('lang.latest_comments')) }}</h5>


        </div>
    </div>
</div>