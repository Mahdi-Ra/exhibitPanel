<div class="row">

    <!--TIMELINE-->
    @include('pages.home.admin.widgets.third-row.events')

    <!--COMMENTS-->

    <!--PROJECTS-->
    @include('pages.home.admin.widgets.third-row.projects')


</div>