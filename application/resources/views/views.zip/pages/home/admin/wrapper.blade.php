<!--TOP STATS-->
<div id="js-trigger-home-admin-wrapper">
@include('pages.home.admin.widgets.first-row.wrapper')

@include('pages.home.admin.widgets.second-row.wrapper')

@include('pages.home.admin.widgets.third-row.wrapper')
</div>