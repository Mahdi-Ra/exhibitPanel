<div class="row">
    <div class="d-none" id="client-details-panel">
        @include('pages.client.components.misc.leftpanel')
    </div>
</div>