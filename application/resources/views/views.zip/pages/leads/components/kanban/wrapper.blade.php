<!--main table view-->
@include('pages.leads.components.kanban.kanban')

<!--Update Card Poistion-->