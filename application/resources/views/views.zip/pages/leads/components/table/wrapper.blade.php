<!--bulk actions-->
@include('pages.leads.components.actions.checkbox-actions')

<!--custom table view-->
@include('pages.leads.components.table.table')