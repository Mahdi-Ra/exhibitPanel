<!--main table view-->
@include('pages.notes.components.table.table')