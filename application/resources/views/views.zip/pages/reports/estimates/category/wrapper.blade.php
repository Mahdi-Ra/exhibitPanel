@include('pages.reports.estimates.category.filter')
@include('pages.reports.estimates.category.table')